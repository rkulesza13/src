﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tweetinvi;
using Tweetinvi.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using HttpMethod = System.Net.Http.HttpMethod;
using System.Threading;
using System.Collections.Generic;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private static string api_key = "<INSERT VALUE>";
        private static string api_key_secret = "<INSERT VALUE>";

        private static string access_token = "<INSERT VALUE>";
        private static string access_token_secret = "<INSERT VALUE>";

        private static string bearer_token = "<INSERT VALUE>";

        private const string webServiceURL = "https://api.twitter.com/2/tweets/sample/stream";

        private TwitterClient twitterClient { get; set; }

        private int hashTagsCount { get; set; }

        private List<ITweet> twitterTwteets;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {         
            hashTagsCount = 0;

            textBox1.Text = "";
            label1.Text = "Tweets Count: 0";
            listBox1.Items.Clear();

            twitterTwteets = new List<ITweet>();

            twitterClient = new TwitterClient(api_key, api_key_secret, access_token, access_token_secret);
            GetTweets();
        }

        public async Task<ITweet[]> RequestTweets(string Token)
        {                       
            try
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, webServiceURL))
                {
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                    var response = await twitterClient.Search.SearchTweetsAsync("2022");

                    return response;                    
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        public void AddTweetInfo(ITweet tweet)
        {
            textBox1.AppendText("Date: " + tweet.CreatedAt);
            textBox1.AppendText(Environment.NewLine);
            textBox1.AppendText("Tweet: " + tweet.Text);
            textBox1.AppendText(Environment.NewLine);
            textBox1.AppendText(Environment.NewLine);

            if(hashTagsCount < 10)
            {
                foreach (var ht in tweet.Hashtags)
                {
                    listBox1.Items.Add(ht.Text);
                    hashTagsCount++;

                    if (hashTagsCount == 10)
                        break;
                }
            }
        }
        
        public async void GetTweets()
        {
            try
            {
                var tweets = await RequestTweets(bearer_token);

                foreach (var tweet in tweets)
                {                    
                    twitterTwteets.Add(tweet);
                    AddTweetInfo(tweet);

                    label1.Text = "Tweets Count: " + twitterTwteets.Count.ToString();
                }                
            }
            catch (Exception ex)
            {
                label3.Text = ex.ToString();
            }
        }
    }
}
